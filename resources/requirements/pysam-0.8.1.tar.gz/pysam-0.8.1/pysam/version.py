# pysam versioning information

__version__ = "0.8.1"

__samtools_version__ = "1.1"

__htslib_version__ = "1.1"
