# pysam versioning information

__version__ = "0.8.3"

__samtools_version__ = "1.2"

__htslib_version__ = "1.2.1"
